import React, { useState, useEffect, useRef } from 'react';
import { FormInput } from './FormInput';
import { StatusDisplay } from './StatusDisplay';
import { audioManager } from '../utils/audio';
import { storageUtils } from '../utils/storage';
import { webhookUtils } from '../utils/webhook';

export const MainScreen: React.FC = () => {
  const [username, setUsername] = useState('');
  const [videoCount, setVideoCount] = useState('60');
  const [sheetId, setSheetId] = useState('');
  const [status, setStatus] = useState('');
  const [result, setResult] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const cleanupPollingRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const savedData = storageUtils.loadFormData();
    setUsername(savedData.username);
    setVideoCount(savedData.videoCount);
    setSheetId(savedData.sheetId);
  }, []);

  const saveFormData = () => {
    storageUtils.saveFormData({ username, videoCount, sheetId });
  };

  const handleInitiate = async () => {
    await audioManager.initAudio();
    await audioManager.clickSound();

    // Clear previous results and disable the button
    setStatus('');
    setResult('');
    setIsProcessing(true);

    // Validate user inputs
    const payload = {
      username: username.trim(),
      videoCount: parseInt(videoCount.trim(), 10),
      sheetId: sheetId.trim(),
    };

    if (!payload.username || !payload.videoCount || !payload.sheetId) {
      await audioManager.errorBuzz();
      setStatus('All fields are required.');
      setIsProcessing(false);
      return;
    }

    saveFormData();

    try {
      // Create a new return URL from webhook.site
      setStatus('Generating secure return channel...');
      const returnUrl = await webhookUtils.createReturnChannel();
      const uuid = returnUrl.split('/').pop()!;

      // Start polling for the result from the Make.com automation
      setStatus('Listening for result...');
      cleanupPollingRef.current = await webhookUtils.pollForResult(
        uuid,
        (resultPayload) => {
          audioManager.chime();
          setStatus('Success! Analysis complete.');
          setResult(`<a href="${resultPayload.docUrl}" target="_blank" class="text-blue-400 hover:underline">View Generated Google Doc</a>`);
          setIsProcessing(false);
        },
        (error) => {
          audioManager.failTone();
          console.error('Polling failed:', error);
          setStatus(`Connection error: ${error.message}`);
          setIsProcessing(false);
        }
      );

      // Send the request to Make.com automation
      setStatus('Sending request to automation... This may take a few minutes.');
      const finalPayload = { ...payload, returnUrl };

      const makeResponse = await webhookUtils.sendToMake(finalPayload);

      if (!makeResponse.ok) {
        throw new Error('Failed to send request to the automation.');
      }

      setStatus('Request sent successfully. Waiting for results...');

    } catch (error) {
      await audioManager.failTone();
      setStatus(`An error occurred: ${(error as Error).message}`);
      cleanupPollingRef.current?.();
      setIsProcessing(false);
    }
  };

  useEffect(() => {
    return () => {
      cleanupPollingRef.current?.();
    };
  }, []);

  return (
    <div className="glass p-8 rounded-xl w-full max-w-lg">
      <h1 className="heading-font text-3xl mb-6 text-center text-white">
        WOLVER'S HUB
      </h1>
      
      <div className="space-y-4 mb-6">
        <FormInput
          id="username"
          label="Competitor TikTok Username"
          value={username}
          onChange={setUsername}
          placeholder="e.g., islamabuauf"
        />
        
        <FormInput
          id="videoCount"
          label="Number of Videos"
          value={videoCount}
          onChange={setVideoCount}
          type="number"
          placeholder="e.g., 60"
        />
        
        <FormInput
          id="sheetId"
          label="Google Sheet ID"
          value={sheetId}
          onChange={setSheetId}
          placeholder="Enter the ID from your sheet's URL"
        />
      </div>

      <button
        onClick={handleInitiate}
        disabled={isProcessing}
        className="neon-btn"
      >
        INITIATE ANALYSIS
      </button>
      
      <StatusDisplay status={status} result={result} />
    </div>
  );
};