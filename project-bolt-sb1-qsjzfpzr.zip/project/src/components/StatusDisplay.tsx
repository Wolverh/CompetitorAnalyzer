import React from 'react';

interface StatusDisplayProps {
  status: string;
  result: string;
}

export const StatusDisplay: React.FC<StatusDisplayProps> = ({ status, result }) => {
  return (
    <div className="mt-4 text-center text-sm opacity-90 min-h-[60px]">
      <p className="text-white">{status}</p>
      {result && (
        <div 
          className="mt-2 font-semibold"
          dangerouslySetInnerHTML={{ __html: result }}
        />
      )}
    </div>
  );
};