import React, { useState } from 'react';
import { PasswordInput } from './PasswordInput';
import { audioManager } from '../utils/audio';
import { cookieUtils } from '../utils/storage';

interface LoginScreenProps {
  onLogin: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const STORED_B64 = 'Tm91cmE='; // "Noura" in Base64

  const handleLogin = async () => {
    await audioManager.initAudio();
    
    if (btoa(password) === STORED_B64) {
      await audioManager.chime();
      cookieUtils.setAuthenticated();
      onLogin();
    } else {
      await audioManager.errorBuzz();
      setPassword('');
    }
  };

  return (
    <div className="glass p-8 rounded-xl w-full max-w-md">
      <h1 className="heading-font text-3xl mb-6 text-center text-white">
        WOLVER'S HUB
      </h1>
      
      <div className="mb-6">
        <label htmlFor="password" className="block mb-2 text-white text-sm font-medium">
          Enter Password
        </label>
        <PasswordInput
          value={password}
          onChange={setPassword}
          onEnter={handleLogin}
        />
      </div>

      <button
        onClick={handleLogin}
        className="neon-btn"
      >
        Unlock
      </button>
    </div>
  );
};