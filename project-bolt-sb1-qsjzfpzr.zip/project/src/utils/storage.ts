const COOKIE_NAME = 'wolverAuth';
const STORAGE_PREFIX = 'wolver_';

export const cookieUtils = {
  set: (name: string, value: string, days: number): void => {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    document.cookie = `${name}=${value}; expires=${date.toUTCString()}; path=/; SameSite=Strict; secure`;
  },

  get: (name: string): string | null => {
    const cookie = document.cookie
      .split(';')
      .map(c => c.trim())
      .find(c => c.startsWith(`${name}=`));
    
    return cookie ? cookie.split('=')[1] : null;
  },

  isAuthenticated: (): boolean => {
    return cookieUtils.get(COOKIE_NAME) === '1';
  },

  setAuthenticated: (): void => {
    cookieUtils.set(COOKIE_NAME, '1', 7);
  }
};

export const storageUtils = {
  saveFormData: (data: { username: string; videoCount: string; sheetId: string }): void => {
    localStorage.setItem(`${STORAGE_PREFIX}username`, data.username);
    localStorage.setItem(`${STORAGE_PREFIX}videoCount`, data.videoCount);
    localStorage.setItem(`${STORAGE_PREFIX}sheetId`, data.sheetId);
  },

  loadFormData: (): { username: string; videoCount: string; sheetId: string } => {
    return {
      username: localStorage.getItem(`${STORAGE_PREFIX}username`) || '',
      videoCount: localStorage.getItem(`${STORAGE_PREFIX}videoCount`) || '60',
      sheetId: localStorage.getItem(`${STORAGE_PREFIX}sheetId`) || ''
    };
  }
};