import { WebhookResponse } from '../types';

export const webhookUtils = {
  createReturnChannel: async (): Promise<string> => {
    const proxyUrl = 'https://api.allorigins.win/raw?url=';
    const targetUrl = encodeURIComponent('https://webhook.site/token');
    
    const response = await fetch(proxyUrl + targetUrl, { method: 'POST' });
    
    if (!response.ok) {
      throw new Error('Could not create return channel.');
    }
    
    const tokenData = await response.json();
    return `https://webhook.site/${tokenData.uuid}`;
  },

  pollForResult: async (uuid: string, onResult: (result: WebhookResponse) => void, onError: (error: Error) => void): Promise<() => void> => {
    let isPolling = true;
    let pollCount = 0;
    const maxPolls = 120; // 10 minutes with 5-second intervals
    
    const poll = async () => {
      if (!isPolling || pollCount >= maxPolls) {
        if (pollCount >= maxPolls) {
          onError(new Error('Timeout: No result received within 10 minutes'));
        }
        return;
      }
      
      try {
        const proxyUrl = 'https://api.allorigins.win/get?url=';
        const targetUrl = encodeURIComponent(`https://webhook.site/token/${uuid}/requests?sorting=newest`);
        
        const response = await fetch(proxyUrl + targetUrl);
        
        if (!response.ok) {
          throw new Error('Failed to check for results');
        }
        
        const data = await response.json();
        const requests = JSON.parse(data.contents);
        
        // Look for POST requests with content
        const postRequest = requests.data?.find((req: any) => 
          req.method === 'POST' && req.content
        );
        
        if (postRequest) {
          try {
            const resultPayload = JSON.parse(postRequest.content);
            if (resultPayload?.docUrl) {
              onResult(resultPayload);
              return;
            }
          } catch (parseError) {
            console.error('Error parsing result:', parseError);
          }
        }
        
        pollCount++;
        if (isPolling) {
          setTimeout(poll, 5000); // Poll every 5 seconds
        }
        
      } catch (error) {
        onError(error as Error);
      }
    };
    
    // Start polling
    setTimeout(poll, 2000); // Initial delay of 2 seconds
    
    // Return cleanup function
    return () => {
      isPolling = false;
    };
  },

  sendToMake: async (payload: any): Promise<Response> => {
    const makeWebhookUrl = 'https://hook.eu2.make.com/hll3xsclyahdg9xxnckf1txz3p559dky';
    
    return fetch(makeWebhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  },

  parseEventData: (eventData: string): WebhookResponse | null => {
    try {
      const event = JSON.parse(eventData);
      if (event.method === 'POST') {
        return JSON.parse(event.content);
      }
    } catch (error) {
      console.error('Error parsing event data:', error);
    }
    return null;
  }
};