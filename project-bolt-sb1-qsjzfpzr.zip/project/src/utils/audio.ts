import * as Tone from 'tone';
import { AudioSynthesizers } from '../types';

class AudioManager {
  private audioReady = false;
  private synthesizers: AudioSynthesizers | null = null;

  async initAudio(): Promise<void> {
    if (this.audioReady) return;
    
    try {
      await Tone.start();
      
      this.synthesizers = {
        synth: new Tone.Synth().toDestination(),
        errSynth: new Tone.Synth({ 
          oscillator: { type: 'square' } 
        }).toDestination(),
        clickSynth: new Tone.Synth({ 
          oscillator: { type: 'triangle' }, 
          envelope: { decay: 0.05, release: 0.1 } 
        }).toDestination(),
        failSynth: new Tone.Synth({ 
          oscillator: { type: 'sawtooth' } 
        }).toDestination()
      };
      
      this.audioReady = true;
    } catch (error) {
      console.error('Failed to initialize audio:', error);
      this.audioReady = false;
    }
  }

  private async play(fn: () => void): Promise<void> {
    if (this.audioReady && this.synthesizers) {
      try {
        fn();
      } catch (error) {
        console.error('Audio playback error:', error);
      }
    }
  }

  async chime(): Promise<void> {
    if (!this.synthesizers) return;
    
    await this.play(() => {
      const notes = ['C5', 'E5', 'G5', 'C6'];
      notes.forEach((note, i) => {
        this.synthesizers!.synth.triggerAttackRelease(note, 0.15, `+${i * 0.15}`);
      });
    });
  }

  async errorBuzz(): Promise<void> {
    if (!this.synthesizers) return;
    
    await this.play(() => {
      this.synthesizers!.errSynth.triggerAttackRelease('C2', 0.2);
    });
  }

  async clickSound(): Promise<void> {
    if (!this.synthesizers) return;
    
    await this.play(() => {
      this.synthesizers!.clickSynth.triggerAttackRelease('C6', 0.05);
    });
  }

  async failTone(): Promise<void> {
    if (!this.synthesizers) return;
    
    await this.play(() => {
      const notes = ['C4', 'G3', 'E3', 'C3'];
      notes.forEach((note, i) => {
        this.synthesizers!.failSynth.triggerAttackRelease(note, 0.2, `+${i * 0.15}`);
      });
    });
  }
}

export const audioManager = new AudioManager();