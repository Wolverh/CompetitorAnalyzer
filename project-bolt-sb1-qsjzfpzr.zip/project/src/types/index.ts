export interface FormData {
  username: string;
  videoCount: number;
  sheetId: string;
}

export interface AudioSynthesizers {
  synth: any;
  errSynth: any;
  clickSynth: any;
  failSynth: any;
}

export interface WebhookResponse {
  docUrl?: string;
  error?: string;
}